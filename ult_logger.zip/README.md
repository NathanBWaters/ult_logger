Download the libult_logger.nro file from https://drive.google.com/file/d/1ck1A0ZqcI43SHxJrSKO1HZ8QWUSQ-aEz/view?usp=sharing

Then add that file to sd:/atmosphere/contents/01006A800016E000/romfs/skyline/plugins/

This is similar to the instructions specified at https://gamebanana.com/tuts/12827.

Now, if you play a game, a log file will be automatically recorded to the root of the SD card. 

Send that file and a link to the uploaded replay to nathan@playaid.app and you will get your gameplay analyed.

